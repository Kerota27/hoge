"""from tkinter import *
from tkinter import ttk

root = Tk()
root.mainloop()"""
#import random
"""x = float(input("平熱教えて "))
y = float(input("これ以上だったら休む時の熱教えて "))
print(min(round(random.normalvariate(x, (y-x)/2), 1), round(y-0.1, 1)))"""