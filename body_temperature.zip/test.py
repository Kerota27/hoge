import requests
from pprint import pprint



headers = {
    'Authorization': f'bearer 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'
}
r = requests.get('https://github.com/PiyoPiyo-dev/ADBtool_GUI/archive/refs/heads/main.zip', headers=headers).content


with open("test.zip" ,mode='wb') as f: # wb でバイト型を書き込める
  f.write(r)