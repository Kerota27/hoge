from http import client
from os import access
from flask import Flask, redirect, request, render_template
import requests
from urllib.parse import parse_qs
from pprint import pprint
app = Flask(__name__)

def exchange_code(code):
    data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'code': code,
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = f'code={code}&client_id={client_id}&client_secret={client_secret}'
    r = requests.post('https://github.com/login/oauth/access_token', data=data, headers=headers)
    if "access_token" in r.text:
        return parse_qs(r.text)['access_token'][0]
    else:
        return

@app.route('/')
def hello():
    return redirect(f"https://github.com/login/oauth/authorize?client_id={client_id}&scope=repo")
@app.route('/callback')
def callback():
    code = request.args.get('code')
    res_token = exchange_code(code)
    if res_token:
        return redirect(f"/repos?token={res_token}")
    else:
        return 'Failed to login. Try again'
@app.route('/repos')
def repos():
    token = request.args.get('token')
    headers = {
        'Authorization': f'bearer {token}'
    }
    res = requests.get('https://api.github.com/user/repos', headers=headers)
    label = [i['name'] for i in eval(res.text.replace('true', 'True').replace('false', 'False').replace('null', 'None'))]
    return render_template('form.html', label=label)
if __name__ == "__main__":
    client_id = "fc69139f074a112fa50f"
    client_secret = "b9d0dbd123701313d0a60e9ca6e76a9f48ce4e07"
    app.run('0.0.0.0')
    